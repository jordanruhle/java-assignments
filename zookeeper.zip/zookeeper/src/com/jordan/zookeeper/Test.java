package com.jordan.zookeeper;

public class Test {

	public static void main(String[] args) {
		
			Gorilla Ivan = new Gorilla();
			Ivan.displayEnergyLevel();
			Ivan.throwSomething();
			Ivan.displayEnergyLevel();
			Ivan.throwSomething();
			Ivan.displayEnergyLevel();
			Ivan.throwSomething();
			Ivan.displayEnergyLevel();
			Ivan.eatBananas();
			Ivan.displayEnergyLevel();
			Ivan.eatBananas();
			Ivan.displayEnergyLevel();
			Ivan.climb();
			Ivan.displayEnergyLevel();
			
			Bat Covid = new Bat();
			Covid.displayEnergyLevel();
			Covid.attackTown();
			Covid.displayEnergyLevel();
			Covid.attackTown();
			Covid.displayEnergyLevel();
			Covid.attackTown();
			Covid.displayEnergyLevel();
			Covid.eatHumans();
			Covid.displayEnergyLevel();
			Covid.eatHumans();
			Covid.displayEnergyLevel();
			Covid.fly();
			Covid.displayEnergyLevel();
			Covid.fly();
			Covid.displayEnergyLevel();
			
			
	}

}
